// cloudfunctions/saveUserInfo/index.js
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const db = cloud.database()
  const openid = wxContext.OPENID

  if (!event.userInfo) {
    return { success: false, message: '用户数据不能为空' }
  }

  try {
    // 检查用户是否已存在
    const userQuery = await db.collection('users')
      .where({ _openid: openid })
      .get()

    let result
    if (userQuery.data.length > 0) {
      // 更新现有用户信息
      const userData = {
        ...event.userInfo,
        updateTime: db.serverDate()
      }
      // 删除_id字段，避免更新冲突
      delete userData._id
      delete userData._openid
      
      result = await db.collection('users')
        .doc(userQuery.data[0]._id)
        .update({
          data: userData
        })
    } else {
      // 创建新用户记录
      const userData = {
        ...event.userInfo,
        _openid: openid,
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      }
      
      result = await db.collection('users').add({
        data: userData
      })
    }

    return {
      success: true,
      message: '用户信息已保存至云端'
    }
  } catch (error) {
    console.error('云函数执行失败：', error)
    return {
      success: false,
      message: '保存失败：' + error.message
    }
  }
}