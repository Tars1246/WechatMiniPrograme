// cloudfunctions/getUserInfo/index.js
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })
const db = cloud.database()

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  try {
    // 查询当前用户的最新一条记录
    const res = await db.collection('users')
      .where({
        _openid: wxContext.OPENID
      })
      .orderBy('createTime', 'desc')
      .limit(1)
      .get()

    return {
      success: true,
      data: res.data[0] || null
    }
  } catch (error) {
    return {
      success: false,
      message: '查询失败：' + error.message
    }
  }
}