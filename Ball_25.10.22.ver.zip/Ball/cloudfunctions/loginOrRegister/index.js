// cloudfunctions/loginOrRegister/index.js
const cloud = require('wx-server-sdk')
cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext()
  const db = cloud.database()
  const openid = wxContext.OPENID

  try {
    // 检查用户是否已存在
    const userQuery = await db.collection('users')
      .where({ _openid: openid })
      .get()

    if (userQuery.data.length > 0) {
      // 用户已存在，返回用户信息
      console.log('用户已存在，返回用户信息')
      return {
        success: true,
        isNewUser: false,
        userInfo: userQuery.data[0]
      }
    } else {
      // 新用户，创建基本记录
      console.log('新用户，创建基本记录')
      const newUser = {
        _openid: openid,
        createTime: db.serverDate(),
        updateTime: db.serverDate(),
        hasCompletedInfo: false // 标记用户尚未完善信息
      }
      
      const result = await db.collection('users').add({ data: newUser })
      
      return {
        success: true,
        isNewUser: true,
        userInfo: { ...newUser, _id: result._id }
      }
    }
  } catch (error) {
    console.error('登录/注册失败:', error)
    return {
      success: false,
      message: '登录失败: ' + error.message
    }
  }
}