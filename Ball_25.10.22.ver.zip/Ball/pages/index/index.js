// index.js
Page({
  data: {
    swiperList: [{
        imgUrl: '/static/images/swiper/temp111.jpg'
      }
      // {
      //   imgUrl: '/static/images/swiper/temp111.png'
      // },
      // {
      //   imgUrl: '/static/images/swiper/temp111.png'
      // },
      // {
      //   imgUrl: '/static/images/swiper/temp111.png'
      // }
    ],
    swiperHeight: 400,
    imgHeights: []
  },

  onImageLoad: function (e) {
    const index = e.currentTarget.dataset.index;
    const imgWidth = e.detail.width;
    const imgHeight = e.detail.height;
    const windowInfo = wx.getWindowInfo();
    const screenWidth = windowInfo.windowWidth;
    const calculatedHeight = screenWidth * (imgHeight / imgWidth);
    let imgHeights = this.data.imgHeights;
    imgHeights[index] = calculatedHeight;
    this.setData({
      imgHeights: imgHeights,
      swiperHeight: calculatedHeight
    });
  },

  onSwiperChange: function (e) {
    const current = e.detail.current;
    this.setData({
      swiperHeight: this.data.imgHeights[current]
    });
  }

  /*onLoad(){
    wx.request({
      url: 'url',
      method:'GET',
      success:(res)=>{
        this.setData({
          swiperList:,
          notice:
        })
      }
    })
  }*/


})