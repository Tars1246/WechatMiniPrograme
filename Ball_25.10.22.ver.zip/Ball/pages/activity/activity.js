// pages/activity/activity.js
Page({
  data: {
    searchKeyword: '',
    activityList: [],
    originalList: [],
    searchTimer: null
  },

  onPullDownRefresh: function () {
    console.log('下拉刷新');
    this.loadActivityList();
    wx.stopPullDownRefresh();
  },

  onLoad: function (options) {
    this.loadActivityList();
    // 启用下拉刷新
    wx.startPullDownRefresh({
      success: (res) => {
        console.log('下拉刷新启用成功');
      }
    });
  },

  onShow: function () {
    // 页面显示时重新加载数据，确保新建的活动能显示
    this.loadActivityList();
  },

  loadActivityList: function () {
    wx.showLoading({
      title: '加载中...'
    });
    try {
      const activities = wx.getStorageSync('activityList') || [];

      const processedActivities = activities.map(activity => {
        if (activity.startTime && activity.endTime) {
          return {
            ...activity,
            startTime: activity.startTime.replace(/:\d{2}$/, ''),
            endTime: activity.endTime.replace(/:\d{2}$/, '')
          };
        }
        return activity;
      });

      this.setData({
        activityList: processedActivities,
        originalList: processedActivities
      });
    } catch (error) {
      console.error('加载失败:', error);
    }
    wx.hideLoading();
  },

  // 搜索输入处理
  onSearchInput: function (e) {
    const keyword = e.detail.value;
    this.setData({
      searchKeyword: keyword
    });

    // 清除之前的计时器
    if (this.data.searchTimer) {
      clearTimeout(this.data.searchTimer);
    }

    // 设置新的计时器（300毫秒防抖）
    this.data.searchTimer = setTimeout(() => {
      this.searchActivities(keyword);
    }, 300);
  },

  // 搜索确认
  onSearchConfirm: function (e) {
    const keyword = e.detail.value;
    this.searchActivities(keyword);
  },

  // 执行搜索
  searchActivities: function (keyword) {
    if (!keyword.trim()) {
      this.setData({
        activityList: this.data.originalList
      });
      return;
    }

    const filteredList = this.data.originalList.filter(activity => {
      const searchTerm = keyword.toLowerCase();
      return (activity.name && activity.name.toLowerCase().includes(searchTerm)) ||
        (activity.place && activity.place.toLowerCase().includes(searchTerm)) ||
        (activity.introduction && activity.introduction.toLowerCase().includes(searchTerm));
    });

    this.setData({
      activityList: filteredList
    });
  },

  // 清空搜索
  clearSearch: function () {
    this.setData({
      searchKeyword: '',
      activityList: this.data.originalList
    });
  },

  navigateToCreateActivity: function () {
    console.log('已跳转到创建活动页面');
    wx.navigateTo({
      url: '/subPackage/pages/createActivity/createActivity',
      success: function (res) {
        console.log('跳转成功，页面路径:', res.route);
      },
      fail: function (err) {
        console.error('跳转失败:', err);
      }
    });
  }
});