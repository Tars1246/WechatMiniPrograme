// pages/mine/mine.js
Page({

  // 页面的初始数据
  data: {
    defaultPhoto: '/static/images/login.png',
    userInfo: null,
    isLoggedIn: false
  },

  onLoad: function (options) {
    this.checkLoginStatus()
  },

  onShow: function () {
    // 每次页面显示时检查登录状态
    this.checkLoginStatus()
  },

  checkLoginStatus: function () {
    const app = getApp()

    // 先检查全局状态
    if (app.globalData.userInfo && app.globalData.isLoggedIn) {
      this.setData({
        userInfo: app.globalData.userInfo,
        isLoggedIn: true,
        defaultPhoto: app.globalData.userInfo.avatarUrl || '/static/images/login.png'
      })
      return
    }

    // 检查本地存储
    const storedUserInfo = wx.getStorageSync('userProfile')
    if (storedUserInfo) {
      this.setData({
        userInfo: storedUserInfo,
        isLoggedIn: true,
        defaultPhoto: storedUserInfo.avatarUrl
      })
      app.globalData.userInfo = storedUserInfo
      app.globalData.isLoggedIn = true
      return
    }

    // 需要登录
    this.login()
  },

  login: function () {
    wx.showLoading({
      title: '登录中...'
    })

    wx.cloud.callFunction({
      name: 'loginOrRegister',
      success: (res) => {
        wx.hideLoading()
        const result = res.result

        if (result.success) {
          if (result.isNewUser) {
            // 新用户，跳转到信息完善页面
            wx.showModal({
              title: '欢迎新用户',
              content: '请完善您的个人信息',
              showCancel: false,
              success: () => {
                wx.navigateTo({
                  url: '/subPackage/pages/personalInfo/personalInfo?isNewUser=true'
                })
              }
            })
          } else if (result.userInfo.hasCompletedInfo) {
            // 老用户且已完善信息
            this.setData({
              userInfo: result.userInfo,
              isLoggedIn: true,
              defaultPhoto: result.userInfo.avatarUrl
            })
            wx.setStorageSync('userProfile', result.userInfo)
            getApp().globalData.userInfo = result.userInfo
            getApp().globalData.isLoggedIn = true
          } else {
            // 老用户但未完善信息
            wx.navigateTo({
              url: '/subPackage/pages/personalInfo/personalInfo?isNewUser=false'
            })
          }
        } else {
          wx.showToast({
            title: '登录失败',
            icon: 'none'
          })
        }
      },
      fail: (err) => {
        wx.hideLoading()
        console.error('登录失败:', err)
        wx.showToast({
          title: '网络错误',
          icon: 'none'
        })
      }
    })
  },
  //界面跳转
  goToPersonalInfo: function() {
    // 如果用户已登录，使用真实用户ID
    if (this.data.isLoggedIn && this.data.userInfo) {
      const userId = this.data.userInfo._openid || this.data.userInfo._id || 'unknown'
      const isNewUser = !this.data.userInfo.hasCompletedInfo
      
      console.log('已登录用户跳转，用户ID:', userId, '是否新用户:', isNewUser)
      
      wx.navigateTo({
        url: `/subPackage/pages/personalInfo/personalInfo?userId=${userId}&isNewUser=${isNewUser}`,
        success: (res) => {
          console.log('跳转成功')
        },
        fail: (err) => {
          console.error('跳转失败，错误详情：', err)
          wx.showToast({
            title: '跳转失败',
            icon: 'none'
          })
        }
      })
    } else {
      // 用户未登录，允许进入个人信息页面进行注册
      console.log('用户未登录，允许进入个人信息页面进行注册')
      wx.navigateTo({
        url: '/subPackage/pages/personalInfo/personalInfo?isNewUser=true',
        success: (res) => {
          console.log('跳转到注册页面成功')
        },
        fail: (err) => {
          console.error('跳转失败，错误详情：', err)
          wx.showToast({
            title: '跳转失败',
            icon: 'none'
          })
        }
      })
    }
  },

  loadUserInfo: function () {
    wx.cloud.callFunction({
      name: 'getUserInfo',
      success: (res) => {
        if (res.result.success && res.result.data) {
          // 从云端成功获取数据
          const cloudUserInfo = res.result.data;
          console.log('从云端获取用户信息:', cloudUserInfo);
          this.setData({
            userInfo: cloudUserInfo,
            defaultPhoto: cloudUserInfo.avatarUrl
          });
          // 将云端数据同步到本地存储，作为缓存
          wx.setStorageSync('userProfile', cloudUserInfo);
        } else {
          // 如果云端没有数据，则降级到从本地存储读取
          this.loadFromLocal();
        }
      },
      fail: (err) => {
        console.error('调用云函数失败，降级到本地存储:', err);
        // 网络错误时，降级到从本地存储读取
        this.loadFromLocal();
      }
    });
  },
  goToRegister: function() {
    console.log('用户点击注册按钮')
    // 直接跳转到个人信息页面进行注册
    wx.navigateTo({
      url: '/subPackage/pages/personalInfo/personalInfo?isNewUser=true',
      success: (res) => {
        console.log('跳转到注册页面成功')
      },
      fail: (err) => {
        console.error('跳转失败，错误详情：', err)
        wx.showToast({
          title: '跳转失败',
          icon: 'none'
        })
      }
    })
  },

  // 从本地存储加载
  loadFromLocal: function () {
    const storedUserInfo = wx.getStorageSync('userProfile');
    if (storedUserInfo) {
      this.setData({
        userInfo: storedUserInfo,
        defaultPhoto: storedUserInfo.avatarUrl
      });
    }
  }

})