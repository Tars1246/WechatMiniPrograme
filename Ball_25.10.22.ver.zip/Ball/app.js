// app.js
App({
  globalData: {
    userInfo: null,
    isLoggedIn: false
  },

  onLaunch: function() {
    wx.cloud.init({
      env: 'cloud1-4glir6m8702bec95', // 您的环境ID
      traceUser: true
    })

    // 尝试从本地存储加载用户信息
    try {
      const storedUserInfo = wx.getStorageSync('userProfile')
      if (storedUserInfo) {
        this.globalData.userInfo = storedUserInfo
        this.globalData.isLoggedIn = true
      }
    } catch (error) {
      console.error('读取本地存储失败:', error)
    }
  }
})