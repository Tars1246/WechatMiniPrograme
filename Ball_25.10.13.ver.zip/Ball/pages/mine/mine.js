// pages/mine/mine.js
Page({

  // 页面的初始数据
  data: {
    defaultPhoto: '/static/images/login.png',
    userInfo: null
  },

  onLoad: function (options) {
    const app = getApp();
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo
      });
    }
  },

  onShow: function () {
    // 页面显示时（如从其他页面返回）加载用户信息，确保数据最新
    this.loadUserInfo();
  },

  loadUserInfo: function () {
    // 1. 从本地存储尝试获取用户信息
    const storedUserInfo = wx.getStorageSync('userProfile');
    // 2. 检查是否确实存在用户信息
    if (storedUserInfo) {
      // 3. 如果存在，则更新页面数据，显示用户信息
      this.setData({
        userInfo: storedUserInfo,
        defaultPhoto: storedUserInfo.avatarUrl // 用用户设置的头像覆盖默认头像
      });
    } else {
      // 4. 如果不存在（例如用户首次进入），则保持默认状态
      this.setData({
        userInfo: null,
        defaultPhoto: '/static/images/login.png'
      });
    }
  },

  //界面跳转
  goToPersonalInfo: function () {
    wx.navigateTo({
      url: '/subPackage/pages/personalInfo/personalInfo?userId=12345',
      success: (res) => {
        console.log('跳转成功');
      },
      fail: (err) => {
        console.error('跳转失败，错误详情：', err); // 这里会打印出具体原因
        wx.showToast({
          title: '跳转失败',
          icon: 'none'
        });
      }
    });
  }

})