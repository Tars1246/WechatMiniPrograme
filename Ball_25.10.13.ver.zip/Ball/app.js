// app.js
//云函数环境ID：cloud1-4glir6m8702bec95

App({
  globalData: {
    userInfo: null
  },

  onLaunch: function () {
     // 初始化云开发
     wx.cloud.init({
      env: 'cloud1-4glir5m8702bec95',
      traceUser: true // 开启用户追踪，方便在云函数中获取用户OpenID
    });

    // 小程序启动时，从本地存储加载用户信息到全局变量
    const storedUserInfo = wx.getStorageSync('userProfile');
    if (storedUserInfo) {
      this.globalData.userInfo = storedUserInfo;
    }
  }
})