const cloud = require('wx-server-sdk')
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})

exports.main = async (event, context) => {
  try {
    // 预设活动数据
    const presetActivities = [
      {
        id: 'preset_1',
        name: '周末篮球友谊赛',
        place: '市体育中心篮球场',
        introduction: '欢迎参加周末篮球友谊赛，锻炼身体，结交朋友！活动提供饮水和基础医疗包。',
        coverImage: 'cloud://cloud1-4glir6m8702bec95.636c-cloud1-4glir6m8702bec95-1330264009/perset_images/1.jpg',
        createTime: '2025-10-01 10:00:00',
        startTime: '2025-10-26 14:00:00',
        endTime: '2025-10-26 17:00:00',
        status: '未开始'
      },
      {
        id: 'preset_2',
        name: '读书分享交流会',
        place: '城市图书馆三楼阅览室',
        introduction: '每月一次的读书分享会，带上你最近读的好书，与书友交流心得。',
        coverImage: 'cloud://cloud1-4glir6m8702bec95.636c-cloud1-4glir6m8702bec95-1330264009/perset_images/2.jpg',
        createTime: '2025-10-05 09:00:00',
        startTime: '2025-10-22 19:00:00',
        endTime: '2026-10-22 21:00:00',
        status: '进行中'
      },
      {
        id: 'preset_3',
        name: '环保志愿者活动',
        place: '西山公园',
        introduction: '参与城市绿化环保活动，清理公园垃圾，种植树苗，共建美好家园。',
        coverImage: 'cloud://cloud1-4glir6m8702bec95.636c-cloud1-4glir6m8702bec95-1330264009/perset_images/3.jpg',
        createTime: '2025-09-28 08:00:00',
        startTime: '2025-10-18 08:30:00',
        endTime: '2025-10-18 12:00:00',
        status: '已结束'
      }
    ]

    // 返回预设活动数据
    return {
      code: 0,
      message: 'success',
      data: {
        presetActivities: presetActivities
      }
    }
  } catch (error) {
    console.error('云函数执行错误:', error)
    return {
      code: -1,
      message: '获取预设活动失败',
      error: error.message
    }
  }
}