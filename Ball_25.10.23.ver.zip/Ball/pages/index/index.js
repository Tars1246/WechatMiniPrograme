// index.js
Page({
  data: {
    swiperImages: [
      '/static/images/swiper/temp5.jpg',
      '/static/images/swiper/temp6.jpg',
      '/static/images/swiper/temp7.jpg',
      '/static/images/swiper/temp8.jpg',
      '/static/images/swiper/temp9.jpg'
    ],
    swiperInterval: 3000,
    swiperDuration: 1500
  },

  onLoad: function (options) {
    console.log('轮播图数据加载完成');
    console.log('当前轮播间隔:', this.data.swiperInterval, '毫秒', '\,', '切换动画时长:', this.data.swiperDuration, '毫秒');
  },

  // onSwiperChange: function (e) {
  //   console.log('当前轮播图索引:', e.detail.current);
  // },

  onImageTap: function (e) {
    const index = e.currentTarget.dataset.index;
    console.log('点击了第', index + 1, '张图片');
  },

  changeSwiperSpeed: function (interval, duration) {
    this.setData({
      swiperInterval: interval,
      swiperDuration: duration
    });
    console.log('轮播速度已调整:', interval, '毫秒间隔,', duration, '毫秒动画时长');
  }

})