Page({
  data: {
    searchKeyword: '',
    activityList: [],
    originalList: [],
    searchTimer: null,
    presetActivities: []
  },

  onLoad: function (options) {
    wx.cloud.init({
      env: 'cloud1-4glir6m8702bec95',
      traceUser: true
    });

    this.loadActivityList();
  },

  onShow: function () {
    this.loadActivityList();
  },

  // 下拉刷新
  onPullDownRefresh: function () {
    console.log('下拉刷新');
    this.loadActivityList();
    wx.stopPullDownRefresh();
  },

  loadActivityList: function () {
    wx.showLoading({
      title: '加载中...'
    });

    this.getPresetActivitiesFromCloud();
  },

  getPresetActivitiesFromCloud: function () {
    wx.cloud.callFunction({
      name: 'getPresetActivities',
      success: (res) => {
        console.log('获取预设活动成功:', res);

        let presetActivities = [];
        if (res.result && res.result.code === 0) {
          presetActivities = res.result.data.presetActivities || [];
        } else if (res.result && res.result.presetActivities) {
          presetActivities = res.result.presetActivities;
        }

        const updatedPresetActivities = this.updateActivitiesStatus(presetActivities);

        this.setData({
          presetActivities: updatedPresetActivities
        });
        wx.setStorageSync('presetActivities', updatedPresetActivities);

        this.loadLocalActivities();
      },
      fail: (err) => {
        console.error('获取预设活动失败:', err);
        const cachedPresetActivities = wx.getStorageSync('presetActivities') || [];
        this.setData({
          presetActivities: cachedPresetActivities
        });

        this.loadLocalActivities();
      }
    });
  },

  loadLocalActivities: function () {
    const localActivities = wx.getStorageSync('activityList') || [];
    const updatedLocalActivities = this.updateActivitiesStatus(localActivities);

    const allActivities = [...this.data.presetActivities, ...updatedLocalActivities];

    this.setData({
      activityList: allActivities,
      originalList: allActivities
    });

    wx.hideLoading();
  },

  updateActivitiesStatus: function (activities) {
    const now = new Date().getTime();

    return activities.map(activity => {
      let status = '未开始';
      let statusClass = 'upcoming';

      try {
        const startTime = this.safeDateParse(activity.startTime).getTime();
        const endTime = this.safeDateParse(activity.endTime).getTime();

        if (now >= startTime && now <= endTime) {
          status = '进行中';
          statusClass = 'ongoing';
        } else if (now > endTime) {
          status = '已结束';
          statusClass = 'ended';
        }
      } catch (error) {
        console.error('时间解析错误:', error, activity);
        status = activity.status || '未开始';
        statusClass = 'upcoming';
      }

      return {
        ...activity,
        status: status,
        statusClass: statusClass
      };
    });
  },

  safeDateParse: function (dateString) {
    if (!dateString) return new Date();

    if (dateString.includes('T')) {
      return new Date(dateString);
    } else if (dateString.includes('/')) {
      return new Date(dateString);
    } else if (dateString.includes('-')) {
      const isoString = dateString.replace(' ', 'T') + 'Z';
      return new Date(isoString);
    } else {
      return new Date(dateString);
    }
  },

  onSearchInput: function (e) {
    const keyword = e.detail.value;
    this.setData({
      searchKeyword: keyword
    });

    if (this.data.searchTimer) {
      clearTimeout(this.data.searchTimer);
    }

    this.data.searchTimer = setTimeout(() => {
      this.searchActivities(keyword);
    }, 300);
  },

  onSearchConfirm: function (e) {
    const keyword = e.detail.value;
    this.searchActivities(keyword);
  },

  searchActivities: function (keyword) {
    if (!keyword.trim()) {
      this.setData({
        activityList: this.data.originalList
      });
      return;
    }

    const filteredList = this.data.originalList.filter(activity => {
      const searchTerm = keyword.toLowerCase();
      return (activity.name && activity.name.toLowerCase().includes(searchTerm)) ||
        (activity.place && activity.place.toLowerCase().includes(searchTerm)) ||
        (activity.introduction && activity.introduction.toLowerCase().includes(searchTerm));
    });

    this.setData({
      activityList: filteredList
    });
  },

  clearSearch: function () {
    this.setData({
      searchKeyword: '',
      activityList: this.data.originalList
    });
  },

  navigateToCreateActivity: function () {
    console.log('已跳转到创建活动页面');
    wx.navigateTo({
      url: '/subPackage/pages/createActivity/createActivity',
      success: function (res) {
        console.log('跳转成功，页面路径:', res.route);
      },
      fail: function (err) {
        console.error('跳转失败:', err);
      }
    });
  }
});