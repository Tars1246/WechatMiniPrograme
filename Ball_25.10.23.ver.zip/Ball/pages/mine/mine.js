// pages/mine/mine.js
Page({
  data: {
    defaultPhoto: '/static/images/login.png',
    userInfo: null,
    isLoggedIn: false,
    avatarLoadAttempts: 0
  },

  onLoad: function (options) {
    this.checkLoginStatus();
  },

  onShow: function () {
    this.checkLoginStatus();
  },

  // 检查登录状态
  checkLoginStatus: function () {
    const app = getApp();

    // 1. 先检查全局状态
    if (app.globalData.userInfo && app.globalData.isLoggedIn) {
      const safeAvatarUrl = this.getSafeAvatarUrl(app.globalData.userInfo.avatarUrl);
      this.setData({
        userInfo: app.globalData.userInfo,
        isLoggedIn: true,
        defaultPhoto: safeAvatarUrl
      });
      console.log('从全局数据加载用户信息');
      return;
    }

    // 2. 检查本地存储
    const storedUserInfo = wx.getStorageSync('userProfile');
    if (storedUserInfo) {
      const safeAvatarUrl = this.getSafeAvatarUrl(storedUserInfo.avatarUrl);
      this.setData({
        userInfo: storedUserInfo,
        isLoggedIn: true,
        defaultPhoto: safeAvatarUrl
      });
      app.globalData.userInfo = storedUserInfo;
      app.globalData.isLoggedIn = true;
      console.log('从本地存储加载用户信息');
      return;
    }

    // 3. 需要登录
    console.log('用户未登录，开始登录流程');
    this.login();
  },

  // 获取安全的头像URL（修复临时路径问题）
  getSafeAvatarUrl: function (avatarUrl) {
    if (!avatarUrl) {
      return '/static/images/login.png';
    }

    // 检查是否是临时路径（包含__tmp__或127.0.0.1）
    if (avatarUrl.includes('__tmp__') || avatarUrl.includes('127.0.0.1')) {
      console.warn('检测到临时头像路径，使用默认头像:', avatarUrl);
      return '/static/images/login.png';
    }

    // 检查是否是云文件ID（以cloud://开头）
    if (avatarUrl.startsWith('cloud://')) {
      return avatarUrl;
    }

    return avatarUrl;
  },

  // 登录流程
  login: function () {
    wx.showLoading({
      title: '登录中...'
    });

    wx.cloud.callFunction({
      name: 'loginOrRegister',
      success: (res) => {
        wx.hideLoading();
        const result = res.result;

        if (result.success) {
          if (result.isNewUser) {
            // 新用户，跳转到信息完善页面
            wx.showModal({
              title: '欢迎新用户',
              content: '请完善您的个人信息',
              showCancel: false,
              success: () => {
                wx.navigateTo({
                  url: '/subPackage/pages/personalInfo/personalInfo?isNewUser=true'
                });
              }
            });
          } else if (result.userInfo.hasCompletedInfo) {
            // 老用户且已完善信息
            const safeAvatarUrl = this.getSafeAvatarUrl(result.userInfo.avatarUrl);

            this.setData({
              userInfo: result.userInfo,
              isLoggedIn: true,
              defaultPhoto: safeAvatarUrl
            });

            // 保存到本地存储和全局数据
            wx.setStorageSync('userProfile', result.userInfo);
            getApp().globalData.userInfo = result.userInfo;
            getApp().globalData.isLoggedIn = true;

            console.log('登录成功，用户信息已加载');
          } else {
            // 老用户但未完善信息
            wx.navigateTo({
              url: '/subPackage/pages/personalInfo/personalInfo?isNewUser=false'
            });
          }
        } else {
          console.error('登录失败:', result.message);
          wx.showToast({
            title: '登录失败',
            icon: 'none'
          });
        }
      },
      fail: (err) => {
        wx.hideLoading();
        console.error('登录失败:', err);
        wx.showToast({
          title: '网络错误，请重试',
          icon: 'none'
        });
      }
    });
  },

  // 头像加载错误处理
  onAvatarError: function (e) {
    console.error('头像加载失败:', e.detail);

    // 限制重试次数，避免无限循环
    if (this.data.avatarLoadAttempts < 3) {
      this.setData({
        avatarLoadAttempts: this.data.avatarLoadAttempts + 1,
        defaultPhoto: '/static/images/login.png'
      });

      // 如果是云文件ID加载失败，尝试重新获取用户信息
      if (this.data.userInfo && this.data.userInfo.avatarUrl &&
        this.data.userInfo.avatarUrl.startsWith('cloud://')) {
        console.log('云文件头像加载失败，尝试重新获取用户信息');
        this.loadUserInfoFromCloud();
      }
    } else {
      // 多次尝试失败后，永久使用默认头像
      this.setData({
        defaultPhoto: '/static/images/login.png'
      });
      console.log('头像加载多次失败，已切换到默认头像');
    }
  },

  // 从云端重新获取用户信息
  loadUserInfoFromCloud: function () {
    wx.showLoading({
      title: '重新加载中...'
    });

    wx.cloud.callFunction({
      name: 'getUserInfo',
      success: (res) => {
        wx.hideLoading();
        if (res.result.success && res.result.data) {
          const userInfo = res.result.data;
          const safeAvatarUrl = this.getSafeAvatarUrl(userInfo.avatarUrl);

          this.setData({
            userInfo: userInfo,
            defaultPhoto: safeAvatarUrl
          });

          // 更新本地存储和全局数据
          wx.setStorageSync('userProfile', userInfo);
          getApp().globalData.userInfo = userInfo;

          console.log('从云端重新获取用户信息成功');
        } else {
          console.error('云端用户信息为空或格式错误');
        }
      },
      fail: (err) => {
        wx.hideLoading();
        console.error('从云端获取用户信息失败:', err);
      }
    });
  },

  // 跳转到个人信息页面
  goToPersonalInfo: function () {
    if (this.data.isLoggedIn && this.data.userInfo) {
      const userId = this.data.userInfo._openid || this.data.userInfo._id || 'unknown';
      const isNewUser = !this.data.userInfo.hasCompletedInfo;

      console.log('跳转到个人信息页面，用户ID:', userId, '是否新用户:', isNewUser);

      wx.navigateTo({
        url: `/subPackage/pages/personalInfo/personalInfo?userId=${userId}&isNewUser=${isNewUser}`,
        fail: (err) => {
          console.error('跳转失败:', err);
          wx.showToast({
            title: '跳转失败',
            icon: 'none'
          });
        }
      });
    } else {
      console.log('用户未登录，跳转到注册页面');
      wx.navigateTo({
        url: '/subPackage/pages/personalInfo/personalInfo?isNewUser=true',
        fail: (err) => {
          console.error('跳转失败:', err);
          wx.showToast({
            title: '跳转失败',
            icon: 'none'
          });
        }
      });
    }
  },

  // 跳转到注册页面
  goToRegister: function () {
    console.log('用户点击注册按钮');
    wx.navigateTo({
      url: '/subPackage/pages/personalInfo/personalInfo?isNewUser=true',
      fail: (err) => {
        console.error('跳转失败:', err);
        wx.showToast({
          title: '跳转失败',
          icon: 'none'
        });
      }
    });
  },

  // 手动刷新用户信息（可选功能）
  refreshUserInfo: function () {
    console.log('手动刷新用户信息');
    this.setData({
      avatarLoadAttempts: 0
    });
    this.checkLoginStatus();
  }
});