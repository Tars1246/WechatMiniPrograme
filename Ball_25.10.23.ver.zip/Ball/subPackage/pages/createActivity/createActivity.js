Page({
  data: {
    name: '',
    place: '',
    introduction: '',
    introductionLength: 0,
    coverImage: '',
    isSubmitting: false,
    // 时间选择相关数据
    startTime: '',
    endTime: '',
    startTimeRange: [
      [],
      [],
      [],
      [],
      []
    ], // 年、月、日、时、分
    endTimeRange: [
      [],
      [],
      [],
      [],
      []
    ],
    startTimeValue: [0, 0, 0, 0, 0],
    endTimeValue: [0, 0, 0, 0, 0]
  },

  onLoad: function (options) {
    this.initTimeRange();
  },

  // 初始化时间选择器数据
  initTimeRange: function () {
    const now = new Date();
    const years = [];
    const months = [];
    const days = [];
    const hours = [];
    const minutes = [];

    // 生成年份选项（当前年和下一年）
    for (let i = now.getFullYear(); i <= now.getFullYear() + 1; i++) {
      years.push(i + '年');
    }

    // 生成月份选项
    for (let i = 1; i <= 12; i++) {
      months.push(i + '月');
    }

    // 生成日期选项（1-31日）
    for (let i = 1; i <= 31; i++) {
      days.push(i + '日');
    }

    // 生成小时选项
    for (let i = 0; i < 24; i++) {
      hours.push(i + '时');
    }

    // 生成分钟选项（每5分钟一个间隔）
    for (let i = 0; i < 60; i += 5) {
      minutes.push((i < 10 ? '0' + i : i) + '分');
    }

    this.setData({
      startTimeRange: [years, months, days, hours, minutes],
      endTimeRange: [years, months, days, hours, minutes]
    });
  },

  // 开始时间改变
  onStartTimeChange: function (e) {
    const value = e.detail.value;
    const timeStr = this.formatSelectedTime(value, this.data.startTimeRange);
    this.setData({
      startTime: timeStr,
      startTimeValue: value
    });
    console.log('选择开始时间:', timeStr);
    // 如果结束时间已选且早于开始时间，重置结束时间
    if (this.data.endTime && new Date(this.data.endTime) <= new Date(timeStr)) {
      this.setData({
        endTime: ''
      });
      wx.showToast({
        title: '结束时间已重置，请重新选择',
        icon: 'none'
      });
    }
  },

  // 结束时间改变
  onEndTimeChange: function (e) {
    const value = e.detail.value;
    const timeStr = this.formatSelectedTime(value, this.data.endTimeRange);
    // 验证结束时间是否晚于开始时间
    if (this.data.startTime && new Date(timeStr) <= new Date(this.data.startTime)) {
      wx.showToast({
        title: '结束时间必须晚于开始时间',
        icon: 'none'
      });
      return; // 不更新结束时间
    }
    this.setData({
      endTime: timeStr,
      endTimeValue: value
    });
    console.log('选择结束时间:', timeStr);
  },

  // 格式化选择的时间
  formatSelectedTime: function (value, range) {
    const year = range[0][value[0]].replace('年', '');
    const month = range[1][value[1]].replace('月', '');
    const day = range[2][value[2]].replace('日', '');
    let hour = range[3][value[3]].replace('时', '');
    hour = parseInt(hour).toString().padStart(2, '0');
    let minute = range[4][value[4]].replace('分', '');
    minute = minute.padStart(2, '0');
    return `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')} ${hour}:${minute}:00`;
  },

  // 活动名称输入处理
  onActNameInput: function (event) {
    let value = event.detail.value;
    if (value.length > 12) {
      value = value.substring(0, 12);
      this.setData({
        name: value
      });
      wx.showToast({
        title: '活动名称最多12字',
        icon: 'none',
        duration: 1500
      });
    } else {
      this.setData({
        name: value
      });
    }
  },

  // 活动地点输入处理
  onActPlaceInput: function (event) {
    let value = event.detail.value;
    if (value.length > 18) {
      value = value.substring(0, 18);
      this.setData({
        place: value
      });
      wx.showToast({
        title: '活动地点最多18个字',
        icon: 'none',
        duration: 1500
      });
    } else {
      this.setData({
        place: value
      });
    }
  },

  // 活动名称失去焦点
  onActName: function (event) {
    const value = event.detail.value;
    this.setData({
      name: value
    });
    if (value.length > 0) {
      console.log('用户输入的活动名称为', value);
    }
  },

  // 活动地点失去焦点
  onActPlace: function (event) {
    const value = event.detail.value;
    this.setData({
      place: value
    });
    console.log('用户输入的活动地点为', value);
  },

  // 活动简介输入
  onMessageInput: function (event) {
    const currentIntroduction = event.detail.value;
    const currentLength = currentIntroduction.length;

    this.setData({
      introduction: currentIntroduction,
      introductionLength: currentLength
    });
  },

  // 活动简介失去焦点
  onMessageChange: function (event) {
    const currentIntroduction = event.detail.value;
    this.setData({
      introduction: currentIntroduction,
      introductionLength: currentIntroduction.length
    });
    console.log('最终的活动简介', currentIntroduction);
  },

  // 选择封面图片
  chooseCoverImage: function () {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      maxDuration: 30,
      camera: 'back',
      success: (res) => {
        console.log('选择图片成功:', res);

        if (res.tempFiles && res.tempFiles.length > 0) {
          const tempFilePath = res.tempFiles[0].tempFilePath;

          this.setData({
            coverImage: tempFilePath
          });

          this.uploadCoverImage(tempFilePath);
        }
      },
      fail: (err) => {
        console.error('选择图片失败:', err);
        wx.showToast({
          title: '选择图片失败',
          icon: 'none'
        });
      }
    });
  },

  // 上传封面图片
  uploadCoverImage: function (tempFilePath) {
    wx.showLoading({
      title: '上传中...'
    });

    const timestamp = new Date().getTime();
    const randomStr = Math.random().toString(36).substring(2, 8);
    const cloudPath = `activity-covers/${timestamp}-${randomStr}.jpg`;

    wx.cloud.uploadFile({
      cloudPath: cloudPath,
      filePath: tempFilePath,
      success: (res) => {
        wx.hideLoading();
        console.log('上传成功:', res);

        const fileID = res.fileID;
        this.setData({
          coverImage: fileID
        });

        wx.showToast({
          title: '上传成功',
          icon: 'success'
        });
      },
      fail: (err) => {
        wx.hideLoading();
        console.error('上传失败:', err);
        wx.showToast({
          title: '上传失败',
          icon: 'none'
        });

        this.setData({
          coverImage: tempFilePath
        });
      }
    });
  },

  // 提交活动信息
  submitActInfo: function () {
    const {
      name,
      place,
      introduction,
      coverImage,
      startTime,
      endTime
    } = this.data;

    if (this.data.isSubmitting) {
      return;
    }
    this.setData({
      isSubmitting: true
    });

    // 验证活动名称
    if (!name.trim()) {
      wx.showToast({
        title: '请填写活动名称',
        icon: 'none'
      });
      this.setData({
        isSubmitting: false
      });
      return;
    }

    // 验证活动简介长度
    if (introduction.length > 200) {
      wx.showToast({
        title: '活动简介不能超过200字',
        icon: 'none'
      });
      this.setData({
        isSubmitting: false
      });
      return;
    }

    // 验证开始时间
    if (!startTime) {
      wx.showToast({
        title: '请选择开始时间',
        icon: 'none'
      });
      this.setData({
        isSubmitting: false
      });
      return;
    }

    // 验证结束时间
    if (!endTime) {
      wx.showToast({
        title: '请选择结束时间',
        icon: 'none'
      });
      this.setData({
        isSubmitting: false
      });
      return;
    }
    // 验证时间顺序
    if (endTime && new Date(endTime) <= new Date(startTime)) {
      wx.showToast({
        title: '结束时间须晚于开始时间',
        icon: 'none'
      });
      this.setData({
        isSubmitting: false
      });
      return;
    }

    // 准备活动数据
    const activityData = {
      id: 'activity_' + new Date().getTime(),
      name: name.trim(),
      place: place.trim(),
      introduction: introduction.trim(),
      coverImage: coverImage || '/static/images/default-cover.png',
      createTime: this.formatTime(new Date()),
      startTime: startTime,
      endTime: endTime,
      status: '未开始'
    };

    console.log('提交的活动信息：', activityData);

    // 保存到本地存储
    let activityList = wx.getStorageSync('activityList') || [];
    activityList.unshift(activityData);
    wx.setStorageSync('activityList', activityList);

    console.log('活动已保存到本地存储');

    // 显示成功提示并返回
    wx.showToast({
      title: '创建成功',
      icon: 'success',
      duration: 1500,
      success: () => {
        setTimeout(() => {
          const pages = getCurrentPages();
          const prevPage = pages[pages.length - 2];

          if (prevPage && prevPage.route === 'pages/activity/activity') {
            prevPage.loadActivityList();
          }
          wx.navigateBack();
        }, 1000);
      }
    });

    // 重置提交状态
    setTimeout(() => {
      this.setData({
        isSubmitting: false
      });
    }, 2000);
  },

  // 时间格式化辅助函数
  formatTime: function (date) {
    const year = date.getFullYear();
    const month = date.getMonth() + 1;
    const day = date.getDate();
    const hours = date.getHours();
    const minutes = date.getMinutes();

    return `${year}-${month < 10 ? '0' + month : month}-${day < 10 ? '0' + day : day} ${hours < 10 ? '0' + hours : hours}:${minutes < 10 ? '0' + minutes : minutes}`;
  }
});