const areaData = [{
    districts: '/',
    streets: ['/']
  },
  {
    districts: '锦江区',
    streets: ['锦官驿街道', '东湖街道', '锦华路街道', '春熙路街道', '书院街街道', '牛市口街道', '沙河街道', '狮子山街道', '成龙路街道', '柳江街道', '三圣街道']
  },
  {
    districts: '青羊区',
    streets: ['草市街街道', '西御河街道', '少城街道', '草堂路街道', '府南街道', '光华街道', '金沙街道', '黄田坝街道', '苏坡街道', '文家街道', '蔡桥街道', '康河街道']
  },
  {
    districts: '金牛区',
    streets: ['西安路街道', '西华街道', '荷花池街道', '驷马桥街道', '茶店子街道', '抚琴街道', '九里堤街道', '五块石街道', '营门口街道', '金泉街道', '沙河源街道', '天回镇街道', '凤凰山街道']
  },
  {
    districts: '武侯区',
    streets: ['浆洗街街道', '望江路街道', '玉林街道', '火车南站街道', '晋阳街道', '红牌楼街道', '簇桥街道', '机投桥街道', '金花桥街道', '簇锦街道', '华兴街道', '芳草街街道', '肖家河街道', '石羊街道', '桂溪街道']
  },
  {
    districts: '成华区',
    streets: ['猛追湾街道', '双桥子街道', '府青路街道', '二仙桥街道', '跳蹬河街道', '双水碾街道', '万年场街道', '保和街道', '青龙街道', '龙潭街道', '白莲池街道']
  },
]

Page({

  // 页面的初始数据
  data: {
    defaultPhoto: '/static/images/login.png',
    username: "",
    genderArray: ['男', '女'],
    genderIndex: 0,
    multiArray: [],
    multiIndex: [0, 0],
    areaData: [],
    number: "",
    signature: "",
    isUploadingAvatar: false
  },


  onLoad: function (options) {
    console.log('页面参数:', options);

    const userId = options.userId || 'unknown';
    const isNewUser = options.isNewUser === 'true';

    console.log('用户ID:', userId, '是否新用户:', isNewUser);

    if (isNewUser) {
      wx.showToast({
        title: '请完善个人信息',
        icon: 'none',
        duration: 2000
      });
    }

    try {
      const savedUserInfo = wx.getStorageSync('userProfile');
      if (savedUserInfo) {
        console.log('找到已保存的用户信息:', savedUserInfo);

        // 检查头像是否为临时路径，如果是则使用默认头像
        const safeAvatarUrl = this.getSafeAvatarUrl(savedUserInfo.avatarUrl);

        this.setData({
          defaultPhoto: safeAvatarUrl,
          username: savedUserInfo.nickname,
          genderIndex: this.data.genderArray.findIndex(item => item === savedUserInfo.gender),
          region: savedUserInfo.region,
          number: savedUserInfo.phoneNumber,
          signature: savedUserInfo.signature
        });
      }
    } catch (err) {
      console.error('读取用户信息失败：', err);
    }

    this.initPickerData();
  },

  getSafeAvatarUrl: function (avatarUrl) {
    if (!avatarUrl) {
      return '/static/images/login.png';
    }

    // 检查是否是临时路径（包含__tmp__或127.0.0.1）
    if (avatarUrl.includes('__tmp__') || avatarUrl.includes('127.0.0.1')) {
      console.warn('检测到临时头像路径，使用默认头像:', avatarUrl);
      return '/static/images/login.png';
    }

    // 检查是否是云文件ID（以cloud://开头）
    if (avatarUrl.startsWith('cloud://')) {
      return avatarUrl;
    }

    return avatarUrl;
  },

  // 获取头像
  choosePhoto: function (event) {
    console.log('chooseAvatar event:', event);
    if (event.detail && event.detail.avatarUrl) {
      const tempFilePath = event.detail.avatarUrl;
      this.uploadAvatarToCloud(tempFilePath);
    } else {
      console.warn('获取头像失败或用户取消', event);
    }
  },

  // 上传头像到云存储
  uploadAvatarToCloud: function (tempFilePath) {
    if (this.data.isUploadingAvatar) {
      return;
    }

    this.setData({
      isUploadingAvatar: true
    });
    wx.showLoading({
      title: '上传头像中...'
    });

    const timestamp = new Date().getTime();
    const randomStr = Math.random().toString(36).substring(2, 8);
    const cloudPath = `user-avatars/${timestamp}-${randomStr}.jpg`;

    wx.cloud.uploadFile({
      cloudPath: cloudPath,
      filePath: tempFilePath,
      success: (res) => {
        wx.hideLoading();
        console.log('头像上传成功:', res);

        const fileID = res.fileID;
        this.setData({
          defaultPhoto: fileID,
          isUploadingAvatar: false
        });

        wx.showToast({
          title: '头像上传成功',
          icon: 'success'
        });
      },
      fail: (err) => {
        wx.hideLoading();
        console.error('头像上传失败:', err);
        this.setData({
          isUploadingAvatar: false
        });

        wx.showToast({
          title: '头像上传失败',
          icon: 'none'
        });

        // 上传失败，仍然使用临时路径（不推荐）
        this.setData({
          defaultPhoto: tempFilePath
        });
      }
    });
  },

  //昵称
  onUsernameInput: function (e) {
    const currentValue = e.detail.value
    this.setData({
      username: currentValue
    });
    console.log('当前输入的昵称：', currentValue);
  },

  //性别
  onGenderChange: function (event) {
    if (event.detail.value == 0) {
      console.log('选择性别为男');
    } else {
      console.log('选择性别为女')
    }
    this.setData({
      genderIndex: event.detail.value
    })
  },

  //地区
  initPickerData: function () {
    const districts = areaData.map(item => item.districts);
    const streets = areaData[0].streets;

    this.setData({
      multiArray: [districts, streets],
      multiIndex: [0, 0]
    });
  },

  onRegionColumnChange: function (e) {
    console.log('column change', e.detail);
    const column = e.detail.column;
    const value = e.detail.value;

    let {
      multiArray,
      multiIndex
    } = this.data;

    multiIndex[column] = value;

    if (column === 0) {
      multiArray[1] = areaData[value].streets;
      multiIndex[1] = 0;

      this.setData({
        multiArray: multiArray,
        multiIndex: multiIndex
      });
    }
  },

  onRegionChange: function (e) {
    console.log('region change', e.detail);
    const indexs = e.detail.value;

    const districtIndex = indexs[0];
    const streetIndex = indexs[1];

    const selectedDistrict = this.data.multiArray[0][districtIndex];
    const selectedStreet = this.data.multiArray[1][streetIndex];
    const fullRegion = `[${districtIndex}]${selectedDistrict} - [${streetIndex + 1}]${selectedStreet}`;

    this.setData({
      multiIndex: indexs,
      region: fullRegion
    });

    console.log('选择的地区是：', fullRegion);
  },

  //联系方式
  onNumberInput: function (e) {
    const currentValue = e.detail.value
    this.setData({
      number: currentValue
    });
    console.log('当前输入的联系方式：', currentValue);
  },

  onNumberBlur: function (e) {
    const inputVal = e.detail.value;
    const phoneReg = /^1[3-9]\d{9}$/;
    if (!inputVal) {
      wx.showToast({
        title: '请输入联系方式',
        icon: 'none'
      });
    } else if (!phoneReg.test(inputVal)) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      });
    }
    console.log('当前失去焦点输入的联系方式：', inputVal);
  },

  //个性签名
  onSignatureBlur: function (e) {
    const currentValue = e.detail.value
    this.setData({
      signature: currentValue
    });
    console.log('个性签名：', currentValue);
  },

  // 提交用户信息
  submitUserInfo: function () {
    // 检查头像是否为临时路径
    if (this.data.defaultPhoto.includes('__tmp__') || this.data.defaultPhoto.includes('127.0.0.1')) {
      wx.showModal({
        title: '提示',
        content: '头像尚未上传成功，请等待上传完成或重新选择头像',
        showCancel: false
      });
      return;
    }

    const userInfo = {
      avatarUrl: this.data.defaultPhoto,
      nickname: this.data.username,
      gender: this.data.genderArray[this.data.genderIndex],
      region: this.data.region || '未选择',
      phoneNumber: this.data.number,
      signature: this.data.signature,
      hasCompletedInfo: true,
      updateTime: new Date()
    }

    console.log('提交的用户信息详情：', userInfo);

    wx.showLoading({
      title: '保存中...'
    });

    wx.cloud.callFunction({
      name: 'saveUserInfo',
      data: {
        userInfo: userInfo
      },
      success: (res) => {
        wx.hideLoading();
        const result = res.result;
        if (result.success) {
          console.log('云端保存成功', result);

          // 在本地也存一份
          wx.setStorageSync('userProfile', userInfo);

          // 更新全局状态
          const app = getApp();
          app.globalData.userInfo = userInfo;
          app.globalData.isLoggedIn = true;

          wx.showToast({
            title: '保存成功',
            icon: 'success',
            duration: 1500,
            success: () => {
              setTimeout(() => {
                wx.switchTab({
                  url: '/pages/mine/mine'
                });
              }, 1000);
            }
          });
        } else {
          console.error('云端保存失败：', result.message);
          wx.showToast({
            title: '保存失败：' + result.message,
            icon: 'none'
          });
        }
      },
      fail: (err) => {
        wx.hideLoading();
        console.error('调用云函数失败：', err);
        wx.showToast({
          title: '网络错误，请重试',
          icon: 'none'
        });
      }
    });
  }
})